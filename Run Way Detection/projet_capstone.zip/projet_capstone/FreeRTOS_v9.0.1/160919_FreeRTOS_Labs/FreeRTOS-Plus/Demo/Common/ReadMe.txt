Contains examples and other files that are used by multiple demos, running on
multiple hardware platforms.
