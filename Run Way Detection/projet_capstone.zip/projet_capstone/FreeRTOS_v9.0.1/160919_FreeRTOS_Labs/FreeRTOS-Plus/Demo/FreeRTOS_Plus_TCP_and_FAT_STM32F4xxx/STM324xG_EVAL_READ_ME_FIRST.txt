STM324xG-EVAL information

According to the STM3240G-EVAL User manual ETM/ETB Trace is not 
guaranteed for clock speeds above 120MHz. 
